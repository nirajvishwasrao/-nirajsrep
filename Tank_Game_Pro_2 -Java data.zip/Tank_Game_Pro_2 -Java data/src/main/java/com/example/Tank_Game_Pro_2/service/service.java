package com.example.Tank_Game_Pro_2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Tank_Game_Pro_2.table.tableclass;
import com.example.Tank_Game_Pro_2.userrepositary.userrepositary;

@Service
public class service {
	List<Integer> second_tank;
	List<Integer> first_tank;

	@Autowired
	userrepositary repo;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public service() {
		super();
		// TODO Auto-generated constructor stub
	}

	public service(List<Integer> second_tank, List<Integer> first_tank, userrepositary repo) {
	super();
	this.second_tank = second_tank;
	this.first_tank = first_tank;
	this.repo = repo;
}

	public List<Integer> getSecond_tank() {
		return second_tank;
	}

	public List<Integer> getFirst_tank() {
		return first_tank;
	}

	public userrepositary getRepo() {
		return repo;
	}

	public void setSecond_tank(List<Integer> second_tank) {
		this.second_tank = second_tank;
	}

	public void setFirst_tank(List<Integer> first_tank) {
		this.first_tank = first_tank;
	}

	public void setRepo(userrepositary repo) {
		this.repo = repo;
	}
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public  ResponseEntity<Object> mehthod1(int tankid) {
		System.out.println("tank 1 id is " +tankid);
		Optional<tableclass> method1;
		method1 = repo.findById(tankid);

		if (method1.isPresent()) {
			tableclass meth1 = method1.get();
			int cost = meth1.getCost();
			int crew = meth1.getCrew();
			int engine = meth1.getEngine();
			int gun = meth1.getGun();
			int lwh = meth1.getLwh();
			int mass = meth1.getMass();
			int max_speed = meth1.getMax_speed();
			int OPrange = meth1.getOPrange();
			int pwratio = meth1.getPw();

			first_tank = new ArrayList<>();
			int[] tank_array = { mass, lwh, crew, gun, engine, pwratio, OPrange, max_speed, cost, };

			for (int val : tank_array) {
				first_tank.add(val);
			}
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			try {
				throw new exeption();
			} catch (Exception ex) {
				System.out.println(ex+"error");
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

			}
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public ResponseEntity<Object> mehthod2(int tankid) {
		System.out.println("tank 2 id is " +tankid);

		Optional<tableclass> method2;
		method2 = repo.findById( tankid);

		if (method2.isPresent()) {
			tableclass meth2 = method2.get();
			int cost = meth2.getCost();
			int crew = meth2.getCrew();
			int engine = meth2.getEngine();
			int gun = meth2.getGun();
			int lwh = meth2.getLwh();
			int mass = meth2.getMass();
			int max_speed = meth2.getMax_speed();
			int OPrange = meth2.getOPrange();
			int pwratio = meth2.getPw();

			second_tank = new ArrayList<>();
			int[] tank_array = { mass, lwh, crew, gun, engine, pwratio, OPrange, max_speed, cost, };

			for (int val : tank_array) {
				second_tank.add(val);
			}

		} else {
			try {
				throw new exeption();
			} catch (Exception ex) {
				System.out.println(" some error occured " + ex);
			}
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public ResponseEntity<String> victorious() {
		System.out.println("hello world...for result");

		int points1 = 0;
		int points2 = 0;
		int neutral = 0;
		for (int i = 0; i < first_tank.size(); i++) {
			if (i < 3) {
				if (second_tank.get(i) > first_tank.get(i)) {
					points1++;
				} else if (first_tank.get(i) > second_tank.get(i)) {
					points2++;
				} else {
					neutral++;
				}

			} else if (i > 2 && i < 8) {
				if (first_tank.get(i) > second_tank.get(i)) {
					points1++;
				} else if (first_tank.get(i) < second_tank.get(i)) {
					points2++;
				} else {
					neutral++;
				}
			} else {
				if (first_tank.get(i) < second_tank.get(i)) {
					points2++;
				} else if (first_tank.get(i) > second_tank.get(i)) {
					points1++;
				} else {
					neutral++;

				}
			}

		}

		if (points2 > points1) {

			return new ResponseEntity<>(" Player Two  Victory points are "+points2+"/9 | "+
					"\n player one points are "+points1+"/9 | "+
					"\n  neutral points are "+neutral+"/9 | "+"" , HttpStatus.OK);

		} else if (points2 < points1) {

			return new ResponseEntity<>(" Player One  Victory points are "+points1+"/9 | "+
					"\n player two points are "+points2+"/9 | "+
					"\n neutral points are "+neutral+"/9 | " , HttpStatus.OK);

		} else {
			return new ResponseEntity<>(" neutral victory " , HttpStatus.OK);

		}

	}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
}
