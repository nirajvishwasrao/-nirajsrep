package Accounts;

public class Report {

	
	 int accountNumber;
	 String Name;
	 double balance;
	 String Operation;
	 public Report() {
		// TODO Auto-generated constructor stub
	}
	public Report(int accountNumber, String name, double balance,String Operation) {
		super();
		this.accountNumber = accountNumber;
		Name = name;
		this.balance = balance;
		this.Operation=Operation;
		
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	

	public String getOperation() {
		return Operation;
	}
	public void setOperation(String operation) {
		Operation = operation;
	}
	public void display_report() {
		System.out.println("※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※");
		System.out.println("Acc number :"+this.accountNumber);
		System.out.println("Acc Holder Name:" +this.Name);
		System.out.println("Balance: ₹"+this.balance);
		System.out.println("Operation:"+Operation);
		System.out.println("※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※");
	}
}
