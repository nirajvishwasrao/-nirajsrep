package com.niraj.angularapplication.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table; 

@Entity
@Table(name = "firsttable")
public class entity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int empid;
	String empname;
	int empsal;
	String empdept;

	public entity() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getEmpid() {
		return empid;
	}

	public String getEmpname() {
		return empname;
	}

	public int getEmpsal() {
		return empsal;
	}

	public String getEmpdept() {
		return empdept;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public void setEmpsal(int empsal) {
		this.empsal = empsal;
	}

	public void setEmpdept(String empdept) {
		this.empdept = empdept;
	}

}
