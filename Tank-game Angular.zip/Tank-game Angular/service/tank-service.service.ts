import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


const Basic_url = ["http://localhost:8080"]
@Injectable({
  providedIn: 'root'
})
export class TankServiceService {

  constructor( private http : HttpClient) { }

  
  FirstTank(tankid : number): Observable<any>{

    return this.http.get(Basic_url+`/select/first?tankid=${tankid}`)
  }


  SecondTank( tankid : number): Observable <any>{
    return this.http.get(Basic_url+`/select/second?tankid=${tankid}`)
  }



Result() : Observable<String>{
  return this.http.get/*<string>*/(Basic_url + `/select/victory`,{ responseType: 'text' })
  //string is excluded
}

}

//


// 

  
  // deleteallcustomer(empid:number): Observable<any> {
  //   return this.http.delete(BASIC_URL + `api/delete?empid=${empid}`)
  // }