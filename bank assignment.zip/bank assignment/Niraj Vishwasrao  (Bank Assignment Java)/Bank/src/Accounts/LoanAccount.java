package Accounts;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class LoanAccount extends SavingAccount {
      float Monthly_intrest;
      double repaid;
      public LoanAccount() {
		// TODO Auto-generated constructor stub
	}
      public LoanAccount(int A_n,double Bal,String Nm,float I_r,double M_b,float M_i,double rp) {
    	  super();
    	  Monthly_intrest=M_i;
    	  repaid=rp;
      }
	public float getMonthly_intrest() {
		return Monthly_intrest;
	}
	public void setMonthly_intrest(float monthly_intrest) {
		Monthly_intrest = monthly_intrest;
	}
	public double getRepaid() {
		return repaid;
	}
	public void setRepaid(double repaid) {
		this.repaid = repaid;
	}
	public int Acc_Number() {
		 Acc_No= ThreadLocalRandom.current().nextInt(100,200);
	        return Acc_No;
	}
	void withdraw() {
		Scanner sc=new Scanner(System.in);
	     System.out.println("enter amount to take loan ");
	     Min_Balance=sc.nextDouble();
	     Balance=-Min_Balance+(Min_Balance*7.0/100); //7.0 is intrest here
	     System.out.println("your account balance is:"+Balance);
	     
		
	}
	 public void deposite() {
	     
	     Scanner sc=new Scanner(System.in);
	    
	     System.out.println("enter amount to repay for your loan amount");
	     repaid=sc.nextDouble();
	     Balance=Balance+repaid;
	     System.out.println("your account balance is: ₹"+Balance);
	     
	    }
	public void add() {
	    Scanner sc=new Scanner(System.in);
	    	
	    	
	    	System.out.println("Enter your name:");
	    	Name=sc.nextLine();
	    	System.out.println("Your Current loan  Account number is:");
	    	System.out.print(Acc_No);
	    	System.out.println("Enter Loan amount in your account : ₹");
	    	Balance=sc.nextDouble();
	    	Balance=-(Balance+(Balance*7.0)/100);
			
		}
	public void display() {
		System.out.println(" name:"+Name);
		System.out.println(" Acc No"+Acc_No);
		System.out.println(" Loan Amount ₹"+Balance);
	}
      
}
