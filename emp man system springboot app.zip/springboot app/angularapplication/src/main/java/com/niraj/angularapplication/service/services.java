package com.niraj.angularapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niraj.angularapplication.entity.entity;
import com.niraj.angularapplication.repositary.userrepositary;

@Service

public class services {
	@Autowired
	userrepositary repo;

	public services() {
		super();
		// TODO Auto-generated constructor stub
	}

	public services(userrepositary repo) {
		super();
		this.repo = repo;
	}

	public userrepositary getRepo() {
		return repo;
	}

	public void setRepo(userrepositary repo) {
		this.repo = repo;
	}

	public entity postcustomer(entity table) {
		System.out.println(table.getEmpdept());
		System.out.println(table.getEmpname());
		return repo.save(table);
	}
	
	public List<entity> getcustomer(){
		return repo.findAll();
	}
	
	public void   deletecustomer(int id) {
		repo.deleteById(id);
	}
}