package house.automation;

public class InvalidChoice extends Exception {
	
	String msg;
	
	public InvalidChoice() {
		// TODO Auto-generated constructor stub
	}
	
}
