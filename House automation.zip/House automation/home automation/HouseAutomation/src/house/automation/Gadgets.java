package house.automation;

import java.time.LocalTime;

public class Gadgets {

	String status;
	String name;
	LocalTime previousStateTime;
	LocalTime currentStateTime;
	
	public Gadgets() {
		
	}

	public Gadgets(String name) {
		this.status = "OFF" ;
		this.name = name ;
		previousStateTime=LocalTime.now();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getName() {
		return name;
	}
	
	public LocalTime getPreviousStateTime() {
		return previousStateTime;
	}

	public void setPreviousStateTime(LocalTime previousStateTime) {
		this.previousStateTime = previousStateTime;
	}

	public LocalTime getCurrentStateTime() {
		return currentStateTime;
	}

	public void setCurrentStateTime(LocalTime currentStateTime) {
		this.currentStateTime = currentStateTime;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
	
}
