package company;

public class invalidinputexeption extends Exception {

	
	private String message() {
		return "your input is invalid";
		// TODO Auto-generated method stub

	}
}
