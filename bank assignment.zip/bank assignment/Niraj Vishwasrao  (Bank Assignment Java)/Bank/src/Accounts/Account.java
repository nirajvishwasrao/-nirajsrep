package Accounts;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public abstract class Account {
    int Acc_No;
    double Balance;
    String Name;
    float Intrest_Rate;
    int Time_Period_for_intrest;
	  double P_amount; //principle amount.
      public Account() {
		
	}
      public Account(int A_n,double Bal,String Nm,float I_r,int Tp ,double pa) {
    	  Acc_No=A_n;
    	  Balance=Bal;
    	  Name=Nm;
    	  Intrest_Rate=I_r;
    	  Time_Period_for_intrest=Tp;
	      P_amount=pa;
  		
  	}
	public int getAcc_No() {
		return Acc_No;
	}
	public void setAcc_No(int acc_No) {
		Acc_No = acc_No;
	}
	public Double getBalance() {
		return Balance;
	}
	public void setBalance(Double balance) {
		Balance = balance;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public float getIntrest_Rate() {
		return Intrest_Rate;
	}
	public void setIntrest_Rate(float intrest_Rate) {
		Intrest_Rate = intrest_Rate;
	}
	public int getTime_Period_for_intrest() {
		return Time_Period_for_intrest;
	}
	public void setTime_Period_for_intrest(int time_Period_for_intrest) {
		Time_Period_for_intrest = time_Period_for_intrest;
	}
	
	public double getP_amount() {
		return P_amount;
	}
	public void setP_amount(double p_amount) {
		P_amount = p_amount;
	}
	public int Acc_Number() {
		return Acc_No;
		
	}
    abstract void add();
   abstract void display(); 
   abstract void deposite();
   abstract void withdraw();
   abstract void intrest();
    
    
    
    
}
