package com.niraj.angularapplication.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.niraj.angularapplication.entity.entity;
//@Repository
public interface userrepositary extends JpaRepository<entity, Integer>{
//@Query(value="delete from firsttable where empid=?1")
//	Object customMethod(int id);

}
