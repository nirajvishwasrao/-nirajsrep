package com.example.Tank_Game_Pro_2.table;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="tank_battle_pro")
public class tableclass {
	@Id
	 int num;  
	int mass ;
	int  lwh ; 
	int crew ;
	 int gun  ;
	 int engine; 
	 int pw   ;
	 int OPrange; 
	int  max_speed; 
	 int cost;
	public tableclass() {
		super();
		// TODO Auto-generated constructor stub
	}
	public tableclass(int num, int mass, int lwh, int crew, int gun, int engine, int pw, int oPrange, int max_speed,
			int cost) {
		super();
		this.num = num;
		this.mass = mass;
		this.lwh = lwh;
		this.crew = crew;
		this.gun = gun;
		this.engine = engine;
		this.pw = pw;
		OPrange = oPrange;
		this.max_speed = max_speed;
		this.cost = cost;
	}
	public int getNum() {
		return num;
	}
	public int getMass() {
		return mass;
	}
	public int getLwh() {
		return lwh;
	}
	public int getCrew() {
		return crew;
	}
	public int getGun() {
		return gun;
	}
	public int getEngine() {
		return engine;
	}
	public int getPw() {
		return pw;
	}
	public int getOPrange() {
		return OPrange;
	}
	public int getMax_speed() {
		return max_speed;
	}
	public int getCost() {
		return cost;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public void setMass(int mass) {
		this.mass = mass;
	}
	public void setLwh(int lwh) {
		this.lwh = lwh;
	}
	public void setCrew(int crew) {
		this.crew = crew;
	}
	public void setGun(int gun) {
		this.gun = gun;
	}
	public void setEngine(int engine) {
		this.engine = engine;
	}
	public void setPw(int pw) {
		this.pw = pw;
	}
	public void setOPrange(int oPrange) {
		OPrange = oPrange;
	}
	public void setMax_speed(int max_speed) {
		this.max_speed = max_speed;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	 
}
