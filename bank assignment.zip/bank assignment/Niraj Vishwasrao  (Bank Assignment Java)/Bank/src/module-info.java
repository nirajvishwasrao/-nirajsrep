/**
 * 
 */
/**
 * @author samma
 *
 */
module Bank {
}