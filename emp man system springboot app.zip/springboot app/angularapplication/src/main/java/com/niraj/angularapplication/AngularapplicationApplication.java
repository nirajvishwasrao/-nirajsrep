package com.niraj.angularapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularapplicationApplication.class, args);
	}

}
