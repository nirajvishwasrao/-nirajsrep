import { TestBed } from '@angular/core/testing';

import { TankServiceService } from './tank-service.service';

describe('TankServiceService', () => {
  let service: TankServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TankServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
