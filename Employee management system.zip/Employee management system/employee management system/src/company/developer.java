
package company;

import java.util.Scanner;

public class developer extends employee {
	int npd;

	public developer(int id, int sal, String name, int npd) {
		super(id, sal, name);
		this.npd = npd;
		// TODO Auto-generated constructor stub

	}

	public developer() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void calsal() {
		// TODO Auto-generated method stub

	}

	@Override
	public void display() {
		System.out.println(" name of developer is  "+name);
		System.out.println(" id of developer is  "+id);
		System.out.println(" salary of developer is  "+sal);
		System.out.println(" project of developer is  "+npd);
		System.out.println();

		// TODO Auto-generated method stub

	}

	@Override
	public void newemp() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the name of employee");
		name = sc.next();
		System.out.println("enter the id of employee");
		id = sc.nextInt();
		System.out.println("enter the salary of employee");
		sal = sc.nextInt();
		System.out.println("number of project devloped");
		npd = sc.nextInt();
	}

}
