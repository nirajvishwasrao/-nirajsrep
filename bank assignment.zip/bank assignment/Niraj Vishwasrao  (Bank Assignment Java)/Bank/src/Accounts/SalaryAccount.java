package Accounts;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.SimpleTimeZone;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Scanner;

public class SalaryAccount extends SavingAccount {
     int time_limit;
     LocalDate last_transaction_date;
     
     //String Date= new SimpleDateFormat("yyyy_mm_dd_HH_mm_ss").format(Calendar.get);
     public SalaryAccount() {
    	 //last_transaction_date=new LocalDate();
	}
     public SalaryAccount(int A_n,double Bal,String Nm,float I_r,double M_b,int T_l, LocalDate L_t_d) {
    	 super(A_n,Bal,Nm,I_r,M_b, T_l, M_b);
    	 time_limit=T_l;
    	 last_transaction_date=L_t_d;
    	 
     }
	public int getTime_limit() {
		return time_limit;
	}
	public void setTime_limit(int time_limit) {
		this.time_limit = time_limit;
	}
	public  LocalDate getLast_transaction_date() {
		return last_transaction_date;
	}
	public void setLast_transaction_date(LocalDate last_transaction_date) {
		this.last_transaction_date = last_transaction_date;
	}
	public int Acc_Number() {
		 Acc_No= ThreadLocalRandom.current().nextInt(100,200);
	        return Acc_No;
	}
	
    public void add() {
        Scanner sc=new Scanner(System.in);
    	
    	
    	System.out.println("Enter your name:");
    	Name=sc.nextLine();
    	System.out.println("Your Account number is:");
    	System.out.println("↠"+Acc_No);
    	System.out.println("\nEnter Initial Balance in your account :₹");
    	Balance=sc.nextDouble();
    	
    }
    public void deposite() {
    	Scanner sc=new Scanner(System.in);
        
        System.out.println("enter amount to add in your account");
        Min_Balance=sc.nextDouble();
        Balance=Balance+Min_Balance;
        System.out.println("your account balance is:"+Balance);
        
    }
    void withdraw() {
    	Scanner sc=new Scanner(System.in);
	     System.out.println("enter amount to withdraw from your account");
	     Min_Balance=sc.nextDouble();
	     System.out.println("Enter Last Trasaction Date(yyyy-mm-dd):");
	     String t=sc.next();
	    
	     LocalDate today=LocalDate.parse(t);
	     
	     int td=today.getMonthValue();
	     last_transaction_date=LocalDate.now();
	     int ltd=last_transaction_date.getMonthValue();
	     
	     if(td-ltd<=2)
	     {
	          if(Min_Balance<=Balance)
	          {
	          if(Min_Balance<=25000) {

	            
	           Balance=Balance-Min_Balance;
	           System.out.println("your account balance is:"+Balance);
	           
	           }
	          else
	            {
	    	       System.out.println("you can not withdraw more than 25000 at a time");
	            }
	          }
	          else
	          {
	    	     System.out.printf("you can not withdraw money more than ",+Balance);
	          }
	      }
	 	  else
	 	  {
	    	    	System.out.println("your account is frozen");
	 	  }
	    
    }
    
    void intrest() {
		Intrest_Rate= (float) 3.5;
	     System.out.printf(" Annual intrest for saving account is:");
	     System.out.println(Intrest_Rate);
	     Scanner sc=new Scanner(System.in);
	     System.out.println("enter how much months time period using for calculate intrest:");
	     Time_Period_for_intrest=sc.nextInt();
	     System.out.println("Enter principle amount for calculate simple intrest");
	     P_amount = sc.nextDouble();
	     double Si= ((P_amount * Time_Period_for_intrest * Intrest_Rate)/100);
		 System.out.println("Your Simple intrest for saving account is:" +Si);
	}
}
