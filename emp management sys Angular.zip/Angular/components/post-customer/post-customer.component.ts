import { Component } from '@angular/core';
import { CustomerService } from '../../service/customer.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-customer',
  templateUrl: './post-customer.component.html',
  //styleUrl: './post-customer.component.css'
})
export class PostCustomerComponent {
  fg!: FormGroup;

  constructor(private customersrvice: CustomerService,
    private router: Router,
    private fb: FormBuilder) {
  }
  ngOnInit() {
    this.fg = this.fb.group({
      empname: [null, Validators.required],
      empsal: [null, Validators.required],
      empdept: [null, Validators.required],

    })
  }
  postcustomer() {
    
    this.customersrvice.postcustomer(this.fg.value).
    subscribe((res) => { console.log(res)
     this.router.navigateByUrl('/getapi');
    })
  }
}
