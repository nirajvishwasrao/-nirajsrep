package com.niraj.angularapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
