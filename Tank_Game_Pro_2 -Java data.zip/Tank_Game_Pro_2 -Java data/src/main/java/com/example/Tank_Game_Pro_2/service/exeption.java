package com.example.Tank_Game_Pro_2.service;

public class exeption extends Exception {
//return "database is empty";
}
