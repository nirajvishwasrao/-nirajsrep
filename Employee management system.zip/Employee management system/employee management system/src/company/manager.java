package company;
import java.util.*;
public class manager extends employee {
	int hpm;

	public manager() {
		// TODO Auto-generated constructor stub
	}

	public manager(int id, int sal, String name) {
		super(id, sal, name);
		
		// TODO Auto-generated constructor stub
	}

	public manager(int hpm) {
		super();
		this.hpm = hpm;
	}

	public int getHpm() {
		return hpm;
	}

	public void setHpm(int hpm) {
		this.hpm = hpm;
	}

	@Override
	void calsal() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void display() {
		System.out.println(" name of manager is  "+name);
		System.out.println(" id of manager is  "+id);
		System.out.println(" salary of manager is  "+sal);
		System.out.println(" project of manager is  "+hpm);
		System.out.println();

		// TODO Auto-generated method stub
	
	}

	@Override
	void newemp() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enrer the name of employee");
		name = sc.next();
		System.out.println("enrer the id of employee");
		id = sc.nextInt();
		System.out.println("enrer the salary of employee");
		sal = sc.nextInt();
		System.out.println("enter how many project devloped");
		hpm = sc.nextInt();
		// TODO Auto-generated method stub
		
	}

	

}
