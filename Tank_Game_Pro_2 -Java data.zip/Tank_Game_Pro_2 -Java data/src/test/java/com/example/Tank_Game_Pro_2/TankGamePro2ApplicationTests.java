package com.example.Tank_Game_Pro_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TankGamePro2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
