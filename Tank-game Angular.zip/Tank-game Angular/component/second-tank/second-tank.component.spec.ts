import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondTankComponent } from './second-tank.component';

describe('SecondTankComponent', () => {
  let component: SecondTankComponent;
  let fixture: ComponentFixture<SecondTankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SecondTankComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SecondTankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
