package Accounts;

import java.util.HashSet;
import java.time.LocalDate;
import java.time.LocalDateTime;    //importing time n date.
import java.time.format.DateTimeFormatter; 



import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public class CurrentAccount extends Account {
	 
	 double Min_Balance;
	 public CurrentAccount() {
		// TODO Auto-generated constructor stub
	}
	 public CurrentAccount(int A_n,double Bal,String Nm,float I_r,int Tp ,double pa,double MB) {
		 super(A_n,Bal,Nm,I_r, Tp,pa);
		 
		 Min_Balance=MB;
		}
	
	
	public double getMin_Balance() {
		return Min_Balance;
	}
	public void setMin_Balance(double min_Balance) {
		Min_Balance = min_Balance;
	}
	public int  Acc_Number() {
        Acc_No= ThreadLocalRandom.current().nextInt(100,200);
    return Acc_No;
    }
	
	void add() {
    Scanner sc=new Scanner(System.in);
    	
    	
    	System.out.println("Enter your name:");
    	Name=sc.nextLine();
    	System.out.println("Your Current Account number is:");
    	System.out.print(Acc_No);
    	System.out.println("\nEnter Initial Balance in your account :₹");
    	Balance=sc.nextDouble();
		
	}
	void display() {
		System.out.println("your Current account number is: ");
		System.out.print(Acc_No);
		System.out.println("\nyour name is :" +Name);
		System.out.printf("Amount is:₹",+Balance);
		
		
	}
	void deposite() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	     
	     System.out.println("enter amount to add in your account");
	     Min_Balance=sc.nextDouble();
	     Balance=Balance+Min_Balance;
	     System.out.println("your account balance is:₹"+Balance);
	}
	void withdraw() {
		// TODO Auto-generated method stub
		
		
		Scanner sc=new Scanner(System.in);
		System.out.printf("You can withdraw money more than ₹",+Balance);
	     System.out.println("enter amount to withdraw from your account ₹");
	     Min_Balance=sc.nextDouble();
	     Balance=Balance-Min_Balance;

	     System.out.println("your account balance is:₹"+Balance);
	     
	}
	void intrest() {
		Intrest_Rate= (float) 4.0;
	     System.out.printf(" Annual intrest for current account is:");
	     System.out.println(Intrest_Rate);
	     Scanner sc=new Scanner(System.in);
	     System.out.println("enter how much months time period using for calculate intrest:");
	     Time_Period_for_intrest = sc.nextInt();
	     System.out.println("Enter principle amount for calculate simple intrest");
	     P_amount = sc.nextDouble();
	     double Si= ((P_amount * Time_Period_for_intrest * Intrest_Rate)/100);
		 System.out.println("Your Simple intrest amount for saving account is:₹" +Si);
	}
    
	 

}
