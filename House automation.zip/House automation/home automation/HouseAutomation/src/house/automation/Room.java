package house.automation;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;

public class Room {

	String type;
	ArrayList<Gadgets> gadgetArr;
	
	public Room() {
		// TODO Auto-generated constructor stub
		 
	}

	public Room(String type) {
		this.type = type;
		gadgetArr= new ArrayList<Gadgets>();
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public ArrayList<Gadgets> getGadgetArr() {
		return gadgetArr;
	}

	public void setGadgetArr(ArrayList<Gadgets> gadgetArr) {
		this.gadgetArr = gadgetArr;
	}

	public void installGadgets()
	{
		
		Scanner sc = new Scanner (System.in);
		boolean go=false;
		while(go!=true)
		{
			System.out.println("Enter The Name Of The Gadgets You Want To Add In This Room:");
			String gadgetName=sc.next();
			gadgetArr.add(new Gadgets(gadgetName));
			System.out.println(gadgetName+" Added Successfully");
			System.out.println("_________________________________________________________________________");
			
			System.out.println("Do You Want To Add One More Gadget");
			System.out.println("1.Press 1 For Yes");
			System.out.println("2.Press 2 For No");
			int selection=sc.nextInt();
			System.out.println("_________________________________________________________________________");
			
			if(selection==2)
			{
				go=true;
			}
			if(selection<1 || selection>2)
			{
				System.out.println("Invalid Choice!!!");
			}
			
		}
	}
	
	public void switchGadgetSatus()
	{
		boolean check=false;
		try
		{
			
			while(check!=true)
			{
				boolean done=false;
				String switchCh="OFF";
				Scanner sc = new Scanner (System.in); 
				System.out.println("Current Gadgets In This Room Are:");
				for(int index=0;index<gadgetArr.size();index++)
				{
					System.out.println(gadgetArr.get(index).getName());
				}
				System.out.println("_________________________________________________________________________");
				System.out.println("Enter The Name Of That Gadget Whose Status You Want TO Change");
				String gadgetName=sc.next();
				for(int index=0;index<gadgetArr.size();index++)
				{
					
						if(gadgetArr.get(index).getName().equals(gadgetName))
						{
							System.out.println("The Current Status Of "+gadgetArr.get(index).getName() +" : "+gadgetArr.get(index).getStatus());
							System.out.println("Enter Your Choice \n1.For OFF \n2.For ON");
							int choice=sc.nextInt();
							if(choice==1)
							{
								switchCh = "OFF";
							}
							if(choice==2)
							{
								switchCh = "ON";
							}
							if(choice<1 || choice>2)
							{
								System.out.println("Invalid Choice!!!");
							}
							
							if(choice==1 || choice==2)
							{
								if(switchCh == gadgetArr.get(index).getStatus())
								{
									System.out.println("The Gadget Is Already "+ switchCh);
									System.out.println("_________________________________________________________________________");
								}
								else
								{
									LocalTime previousTime = LocalTime.now();
									
									gadgetArr.get(index).setStatus(switchCh);
									System.out.println("The "+ gadgetArr.get(index).getName() + " Is Now "+gadgetArr.get(index).getStatus());
									gadgetArr.get(index).setPreviousStateTime(previousTime);
									System.out.println("_________________________________________________________________________");
									
								}
								
								
							}
							done=true;
							check= true;
						}
				}
				
				if(!done)
				{
					throw new InvalidChoice();
						
				}
			}
		}
		catch(InvalidChoice e)
		{
			System.out.println("Please Enter A Valid Gadget Name!!!");
			System.out.println("_________________________________________________________________________");
		}
	}
	
	public void checkTime()
	{
		boolean check = false;
		Scanner sc = new Scanner (System.in); 
		System.out.println("Current Gadgets In This Room Are:");
		for(int index=0;index<gadgetArr.size();index++)
		{
			System.out.println(gadgetArr.get(index).getName());
		}
		System.out.println("_________________________________________________________________________");
		System.out.println("Enter The Name Of That Gadget Whose Status Time You Want TO Check");
		String gadgetName=sc.next();
		
		
		for(int index=0;index<gadgetArr.size();index++)
		{
			if(gadgetArr.get(index).getName().equals(gadgetName))
			{
				LocalTime currenTime = LocalTime.now();
				gadgetArr.get(index).setCurrentStateTime(currenTime);
				
				int hr = ((gadgetArr.get(index).getCurrentStateTime().getHour())-(gadgetArr.get(index).getPreviousStateTime().getHour()));
				
				int min = ((gadgetArr.get(index).getCurrentStateTime().getMinute())-(gadgetArr.get(index).getPreviousStateTime().getMinute()));
				
				int sec = ((gadgetArr.get(index).getCurrentStateTime().getSecond())-(gadgetArr.get(index).getPreviousStateTime().getSecond()));
				if(sec<0)
				{
					sec=sec+sec;
				}
				if(min<0)
				{
					min=min+min;
				}
				if(hr<0)
				{
					hr=hr+hr;
				}
				
				
				System.out.println("The Gadget "+ gadgetArr.get(index).getName()+" Is "+gadgetArr.get(index).getStatus()+" From Last "+hr+" Hours:"+min+" Minutes:"+sec+" Seconds" );
			
				check = true;
			}
		}
		
		if(!check)
		{
			System.out.println("Gadget Not Found!!!");
			System.out.println("_________________________________________________________________________");
		}
	}
	
	
}
