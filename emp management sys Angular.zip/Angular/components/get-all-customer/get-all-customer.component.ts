import { Component } from '@angular/core';
import { CustomerService } from '../../service/customer.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-get-all-customer',
  templateUrl: './get-all-customer.component.html',
  styleUrl: './get-all-customer.component.css'
})
export class GetAllCustomerComponent {
customers: any=[];

fg!: FormGroup;
constructor(private service: CustomerService,private router:Router, private fb:FormBuilder){}
  ngOnInit() {
    this.fg=this.fb.group({
      empid:[null,Validators.required]
    })
this.getallcustomer();
  }
  
  getallcustomer() {
    this.service.getallcustomer().subscribe((res) => {
      console.log(res);
    this.customers= res;
    })
  }

  deleteemp(){
    const empid = this.fg.get('empid')?.value;

    this.service.deleteallcustomer(empid).subscribe(
      (res)=>{
        console.log(res), this.getallcustomer(); // Reload the current route //this.router.navigate([this.route.snapshot.url]);
    })


   
    
  //  this.getallcustomer();
   // this.router.navigateByUrl('/getapi');

  }
}

