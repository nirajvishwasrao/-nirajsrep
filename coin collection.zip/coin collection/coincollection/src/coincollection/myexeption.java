package coincollection;

public class myexeption extends Exception {

}
