package company;

import java.lang.reflect.Array;
import java.util.*;

public class main {

	public static void main(String[] args) throws invalidinputexeption {

		int u = 0;
		employee[] sam = new employee[10];
// TODO Auto-generated method stub
		while (u != 3) {
			System.out.println();
			System.out.println("Enter 1 for add employee ");
			System.out.println("Enter 2 for display employee ");
			System.out.println("Enter 3 for exit ");
			System.out.println("Enter 4 for search");
			System.out.println("Enter 5 for add salary of all ");
			Scanner sc = new Scanner(System.in);

			u = sc.nextInt();
			if (u <= 0 || u > 5) {
				try {
					throw new invalidinputexeption();

				} catch (Exception e) {
					System.out.println("enter the valid input");
					// TODO: handle exception
				}
			}
			switch (u) {
			case 1: {
				int o = 0;
				int z = 0;

				while (o != 4) {

					System.out.println("Enter 1 for add devloper ");
					System.out.println("Enter 2 for add manager ");
					System.out.println("Enter 3 for add tester ");
					System.out.println("Enter 4 for exit ");

					o = sc.nextInt();
					if (o < 1 || o > 4) {
						try {
							throw new invalidinputexeption();
						} catch (Exception e) {
							System.out.println("please enter valid input ");
						}
					}
					switch (o) {

					case 1: {

						sam[z] = (new developer());
						sam[z].newemp();

						System.out.println("devloper added");
						z++;
						break;
					}
					case 2: {
						sam[z] = (new manager());
						sam[z].newemp();

						System.out.println("manager added");
						z++;
						break;
					}

					case 3: {
						sam[z] = (new tester());
						sam[z].newemp();

						System.out.println("tester added");
						z++;

						break;
					}
					case 4: {
						System.out.println("exited sussesfully");
						break;

					}

					}
				}
				break;
			}
			case 2: {
				int x = 0;
				try {
					while (x <= sam.length) {
						sam[x].display();
						System.out.println();
						x++;
					}
				} catch (Exception e) {
					System.out.println(e);
				}
				break;

			}

			case 4: {
				int jkj = 0;
				int g = 0;
				Scanner sd = new Scanner(System.in);
				System.out.println("enter the name of employee you want to search ");
				String ss = sd.next();
				try {
					while (g < sam.length) {

						if (sam[jkj] != null) {
							if (ss.equals(sam[jkj].name)) {
								sam[jkj].display();

							}
						}
						jkj++;
						g++;

					}
				} catch (Exception e) {
					System.out.println(e);
					e.printStackTrace();
				}
				break;
			}

			case 5: {
				int g = 0;
				// Scanner sd = new Scanner(System.in);
				for (int k = 0; k < sam.length; k++) {
					if (sam[k] != null) {
						g += sam[k].sal;
					}

				}
				System.out.println(g);
			}
				break;
			}

		}
	}
}
