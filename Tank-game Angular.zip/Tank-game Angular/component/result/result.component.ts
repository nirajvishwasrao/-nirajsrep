import { Component } from '@angular/core';
import { TankServiceService } from '../../service/tank-service.service';
@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrl: './result.component.css'
})
export class ResultComponent {
  myresponse :String=''
  constructor ( private ts : TankServiceService){}
  ngOnInit() {
    this.result();
  }

  
    result(){
      this.ts.Result().subscribe (  (response:String)=>  { console.log(response) 
        this.myresponse=response
      } ,
      (error) => {
                  console.error('Error fetching victory message:', error);
                  console.error('Error details:', error.message);
             } )
 
}
}
