package com.niraj.angularapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.niraj.angularapplication.entity.entity;
import com.niraj.angularapplication.service.services;

@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class controller {
	@Autowired
	services serv;

	public controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	public controller(services serv) {
		super();
		this.serv = serv;
	}

	public services getServ() {
		return serv;
	}

	public void setServ(services serv) {
		this.serv = serv;
	}

	@PostMapping("/post")
	public entity postcustomer(@RequestBody entity table) {
		return serv.postcustomer(table);
	}

	@GetMapping("/get")
	public List<entity> getcustomer() {
		System.out.println("hello world...");
		return serv.getcustomer();
	}
@DeleteMapping("/delete")
	//@DeleteMapping("/delete/{empid}")
	public void deletecustomer(/*@PathVariable(name = "empid") int empid*/ @RequestParam(name="empid") int empid ) {
	System.out.println(empid);
		serv.deletecustomer(empid);

	}
}
