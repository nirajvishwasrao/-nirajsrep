import { Component } from '@angular/core';
import { TankServiceService } from '../../service/tank-service.service';

@Component({
  selector: 'app-second-tank',
  templateUrl: './second-tank.component.html',
  styleUrl: './second-tank.component.css'
})
export class SecondTankComponent {

  constructor ( private ts : TankServiceService){

  }

  firsttank1(){
   const tankid = 1
    this.ts.SecondTank(tankid).subscribe((res)=>{
      console.log(res)
    })
  }

  firsttank2(){
    const tankid2 = 2
     this.ts.SecondTank(tankid2).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank3(){
    const tankid3 = 3
     this.ts.SecondTank(tankid3).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank4(){
    const tankid4 = 4
     this.ts.SecondTank(tankid4).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank5(){
    const tankid5 = 5
     this.ts.SecondTank(tankid5).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank6(){
    const tankid6 = 6
     this.ts.SecondTank(tankid6).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank7(){
    const tankid7 = 7
     this.ts.SecondTank(tankid7).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank8(){
    const tankid8 = 8
     this.ts.SecondTank(tankid8).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank9(){
    const tankid9 = 9
     this.ts.SecondTank(tankid9).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank10(){
    const tankid10 = 10
     this.ts.SecondTank(tankid10).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank11(){
    const tankid9 = 11
     this.ts.SecondTank(tankid9).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank12(){
    const tankid9 = 12
     this.ts.SecondTank(tankid9).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank13(){
    const tankid9 = 13
     this.ts.SecondTank(tankid9).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank14(){
    const tankid9 = 14
     this.ts.SecondTank(tankid9).subscribe((res)=>{
       console.log(res)
     })
   }

   firsttank15(){
    const tankid9 = 15
     this.ts.SecondTank(tankid9).subscribe((res)=>{
       console.log(res)
     })
   }
  }