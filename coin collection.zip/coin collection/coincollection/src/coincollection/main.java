package coincollection;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> coin = new ArrayList<>();

		// List <String>List = new ArrayList<>();
//File ss = new File("coincollection2222.txt");
//try {
//	ss.createNewFile();
//} catch (IOException e1) {
//	// TODO Auto-generated catch block
//	e1.printStackTrace();
//}
		Scanner sc = new Scanner(System.in);
		int choice1 = 124248;
		while (choice1 != 0) {
			System.out.println("\nEnter 1 for adding coin into list (Arraylist)");
			System.out.println("Enter 2 for display");
			System.out.println("Enter 3 for more settings");
			System.out.println("Enter 4 for adding coin into list 1(Arraylist)  <- from File");
			System.out.println("Enter 5 for adding coin into list (Arraylist)   <- from Backup(Database)");
			System.out.println("Enter 6 for adding coin into Backup (Database)  <- from List (Arraylist)");
			System.out.println("Enter 7 for adding coin into ArrayList(method 2)   <- from File");
			System.out.println("Enter 8 for sorting ");
			System.out.println("\nEnter 0 for exit");
			choice1 = sc.nextInt();
			if (choice1 < 0 || choice1 > 8) {
				try {
					throw new myexeption();
				} catch (myexeption e) {
					// TODO Auto-generated catch block
					System.out.println(" Please enter correct input ");
				}
			}

			switch (choice1) {

			case 1: {

				System.out.println("\nEnter the country of coin");
				String countryname = sc.next();
				System.out.println("Enter the printed amount of coin ( in rupees )");
				String amount_of_coin = sc.next();
				System.out.println("Enter the year of coin");
				String year_of_coin = sc.next();
				System.out.println("Enter the current price of coin ( in rupees )");
				String prise_of_coin = sc.next();
				coin.add(countryname);
				coin.add(amount_of_coin);
				coin.add(year_of_coin);
				coin.add(prise_of_coin);
				break;
			}

			case 2: {
				int i = 0;

				while (i < coin.size()) {
					System.out.println("\nThe country is  " + coin.get(i));
					i++;
					System.out.println("Printed amount of coin ( in rupees )is  " + coin.get(i));
					i++;
					System.out.println("The year of coin is  " + coin.get(i));
					i++;
					System.out.println("The current price of coin ( in rupees )is  " + coin.get(i));
					i++;
					System.out.println();
				}

				break;
			}

			case 3: {
				int x = 975;
				while (x != 0) {
					System.out.println("Enter 1 for making list by country  ");
					System.out.println("Enter 2 for searching ");
					System.out.println("Enter 0 for exit ");
					x = sc.nextInt();
					// int x=6484;

					if (x < 0 || x > 2) {
						try {
							throw new myexeption();
						} catch (myexeption e) {
							// TODO Auto-generated catch block
							System.out.println(" Please enter correct input ");
						}
					}

					switch (x) {
					case 1: {
						for (int i = 0; coin.get(x) != null; i += 4) {
							System.out.println(coin.get(x));

						}

					}
					case 2: {
						int r = 1245;
						while (r != 0) {
							System.out.println("Enter 1 for searching by country ");
							System.out.println("Enter 2 for searching by printed amount on coin ");
							System.out.println("Enter 3 for searching by year of coin ");
							System.out.println("Enter 4 for searching by current ammount of coin ");
							System.out.println("Enter 5 for searching by country and year of coin ");
							System.out.println("Enter 0 for going back");
							r = sc.nextInt();

							if (r < 0 || x > 5) {
								try {
									throw new myexeption();
								} catch (myexeption e) {
									// TODO Auto-generated catch block
									System.out.println(" Please enter correct input ");
								}
							}

							switch (r) {
							case 1: {
								System.out.println("Enter name of country (this is case secetive )");
								String rr = sc.next();
								int i = 0;
								while (coin.get(i) != null) {
									if (rr.equals(coin.get(i))) {
										System.out.println("FOUND...!!\n" + coin.get(i));
									}
									i += 4;

								}

								break;
							}
							case 2: {

								System.out.println("Enter printed amount on coin(this is case secetive)");
								String rr = sc.next();
								int i = 1;
								while (coin.get(i) != null) {
									if (rr.equals(coin.get(i))) {
										System.out.println("FOUND...!!\n" + coin.get(i));
									}
									i += 4;

								}

								break;
							}
							case 3: {
								System.out.println("Enterby year of coin(this is case secetive)");
								String rr = sc.next();
								int i = 2;
								while (coin.get(i) != null) {
									if (rr.equals(coin.get(i))) {
										System.out.println("FOUND...!!\n" + coin.get(i));
									}
									i += 4;

								}

								break;
							}
							case 4: {

								System.out.println("Enter current ammount of coin (this is case secetive )");
								String rr = sc.next();
								int i = 3;
								while (coin.get(i) != null) {
									if (rr.equals(coin.get(i))) {
										System.out.println("FOUND...!! \n" + coin.get(i));
									}
									i += 4;

								}

								break;
							}
							case 5: {
								String cname = null;
								String yname = null;
								System.out.println("Enter country of coin (this is case secetive");
								String rr = sc.next();
								System.out.println("Enter by year of coin(this is case secetive)");
								String rr1 = sc.next();
								int i = 0;
								int y = 0;
								int i1 = 2;

								try {
									while (coin.get(i) != null) {
										if (rr.equals(coin.get(i))) {
											// System.out.println(coin.get(i));

											if (coin.get(i1) != null) {

												if (rr1.equals(coin.get(i1)) && rr.equals((coin.get(i)))) {
													y++;
													cname = coin.get(i);
													yname = coin.get(i1);
													// System.out.println(y + " Coin Found...!!!\nYear of coin "
													// + coin.get(i1) + " Country of coin " + coin.get(i));
													// y++;
													// System.out.println();
												}

											}

										}
										i1 += 4;
										i += 4;

									}

								} catch (Exception e) {
									// TODO Auto-generated catch block
									// e.printStackTrace();
								}

								System.out.println(" hello my dear friends  ");
								if (y > 0) {
									System.out.println(y + " Coin Found...!!!\nYear of coin " + yname
											+ "  Country of coin " + cname);
									y++;
									System.out.println();
								} else {
									System.out.println(" coin not found.....  ");
								}
								break;
							}
							}

						}
						break;
					}
					}

				}
				break;
			}
			case 4: {
				try {
					BufferedReader aa = new BufferedReader(new FileReader("coincollection.txt"));
					String filedata;
					while ((filedata = aa.readLine()) != null) {
						System.out.println(filedata);

						coin.add(filedata);

					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			}

			case 5: {

				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdb", "root",
							"niraj@123");

					PreparedStatement ps = con.prepareStatement("SELECT * FROM coincollection");

					ResultSet cc = ps.executeQuery();

					while (cc.next()) {
						String country = cc.getString("country");
						String amount = cc.getString("amount");
						String year = cc.getString("year");
						String currentprise = cc.getString("currentprise");
						coin.add(country);
						coin.add(amount);
						coin.add(year);
						coin.add(currentprise);
						// System.out.println( country+ "\n" + amount+ "\n" + year + "\n" + currentprise
						// + "\n");

					}
					con.close();
					cc.close();
					ps.close();
					// PreparedStatement ps =con.prepareStatement("INSERT INTO coincollection
					// VALUE('france' ,'40','1845','90000');");
					// ps.executeUpdate();

				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}

			case 6: {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdb", "root",
							"niraj@123");

					int q = 0;
					int w = 1;
					while (coin.get(q) != null) {

						String cntry = coin.get(q);
						q++;
						String value = coin.get(q);
						q++;
						String year = coin.get(q);
						q++;
						String currval = coin.get(q);
						q++;

						PreparedStatement ps = con.prepareStatement("INSERT INTO coincollection VALUE(?,?,?,?);");

						ps.setString(1, cntry);
						w++;
						ps.setString(2, value);
						w++;
						ps.setString(3, year);
						w++;
						ps.setString(4, currval);
						w = 1;
						ps.executeUpdate();

						con.close();
						// cc.close();
						ps.close();
					}

				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			case 7: {

				try {
					File ff = new File("coincollection.txt");

					Scanner sf = new Scanner(ff);
					while (sf.hasNextLine()) {
						String nxt = sf.nextLine();
						System.out.println(nxt);
						coin.add(nxt);
					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			case 8: {
				List<Integer> srt = new ArrayList<>();
				
				int i = 3;
				while (i < coin.size()) {
					int value = Integer.parseInt(coin.get(i)); // for adding current prise....
					srt.add(value);
					i += 4;
					// int value = coin.get(0);
//srt.sort(value);
					// =srt.sort(null);
					//i++;
				}
				Collections.sort(srt);
				//System.out.println(srt.size());
for (int j =srt.size()-1; j >= 0; j--) {
	//System.out.println("hello2");
	
	System.out.println(	srt.get(j));

	
}
				break;

			}
			}
		}

	}

}
