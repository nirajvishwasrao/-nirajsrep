package com.example.Tank_Game_Pro_2.userrepositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Tank_Game_Pro_2.table.tableclass;
public interface userrepositary extends JpaRepository<tableclass, Integer>{

	
}
