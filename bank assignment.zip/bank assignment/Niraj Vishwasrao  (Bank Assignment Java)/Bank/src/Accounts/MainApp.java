package Accounts;
import java.util.Scanner;



public class MainApp {

	public static void main(String[] args) {
		
		Account[] arr=new Account[10];
		Report[] brr=new Report[100];

		int k=0;
		int n=0;
		int i=0;
		int Sel=0;
		int cnt=0;
		do {
			Scanner sc=new Scanner(System.in);
			System.out.println("▤▤▤▤▤▤▤▤▤▤▤▤▤Choose One▤▤▤▤▤▤▤▤▤▤▤▤▤▤▤▤▤▤▤");
			
			System.out.println(" 1-for Administration log in  \n 2 for user log in \n 3 for exit ");
	   		n=sc.nextInt();
			switch(n)
			{
				case 1:
				{
					int s=0;
					do {
						System.out.println("Enter 1 for create account");
						System.out.println("Enter 2 for display account");
						System.out.println("Enter 3 for Show Daily report ");
						System.out.println("Enter 4 for Admin log out");
						s=sc.nextInt();
						switch(s)
						{
						case 1:
						   {
							   int as=0;
							do {
								
								System.out.println("\n1 for Saving Account:");
								System.out.println("2 for Salary Account:");
								System.out.println("3 for Current Account:");
								System.out.println("4 for Loan Account:");
								System.out.println("5 for exit from acount creation:");
								as=sc.nextInt();
								switch(as)
								   {
								   case 1:
								   {
									arr[cnt]=new SavingAccount();
									arr[cnt].Acc_Number();
									arr[cnt].add();
									brr[k]=new Report(arr[cnt].getAcc_No(),arr[cnt].getName(),arr[cnt].getBalance(),"Created Saving Account");
									cnt++;
									k++;
								   }
								   break;
								   case 2:
								   {
									arr[cnt]=new SalaryAccount();
									arr[cnt].Acc_Number();
									arr[cnt].add();
									brr[k]=new Report(arr[cnt].getAcc_No(),arr[cnt].getName(),arr[cnt].getBalance(),"Created salary account ");
									cnt++;
									k++;
								   }
								   break;
								   case 3:
								   {
									arr[cnt]=new CurrentAccount();
									arr[cnt].Acc_Number();
									arr[cnt].add();
									brr[k]=new Report(arr[cnt].getAcc_No(),arr[cnt].getName(),arr[cnt].getBalance(),"created current account");
									cnt++;
									k++;
								   }
								   break;
								   case 4:
								   {
									arr[cnt]=new SavingAccount();
									arr[cnt].Acc_Number();
									arr[cnt].add();
									brr[k]=new Report(arr[cnt].getAcc_No(),arr[cnt].getName(),arr[cnt].getBalance(),"Created Loan account ");
									cnt++;
								   }
								   break;
								
								   }
						       }while(as!=5);
						    }
					           break;
					    
					           case 2:
					           {
					    	          System.out.println("enter  account number to display:");
				        	          int AcS=sc.nextInt();
			
			        	 
				                      for(i=0;i<cnt;i++)
				                      {
			
					                   if(AcS==arr[i].getAcc_No()) 
					                   {
						                 arr[i].display();
				                       }
				                      }
					       
					           }
				             break;
					           case 3:
					           {
					        	   System.out.println("※※※※※※※※Displaying all Report※※※※※※※※");
					        	   for(i=0;i<k;i++)
					        	   {
					        		   brr[i].display_report();
					        	   }
					           }
					           break;
						}
						
			           }while(s!=4);
				}
				break;
				case 2:
				{
				 int us=0;
				  System.out.println("========USER_SIDE========");
				  do {
					  System.out.println("1 for Deposite amount in your Account");
					  System.err.println("2 for Withdraw money from your Account");
					  System.out.println("3 for calculate your intrest ");
					  System.out.println("4 for delete your bank account");
					  System.out.println("5 for user log out");
					  us=sc.nextInt();
					  switch(us)
					  {
					  case 1:
					  {
						  System.out.println("enter  account number to add money:");
	        	          int ACW=sc.nextInt();
	        	          for(i=0;i<cnt;i++)
	                      {

		                   if(ACW==arr[i].getAcc_No()) 
		                   {
			                 arr[i].deposite();
	                       }
		                   else
		                   {
		                	   System.out.println("account dosent exists");
		                   }
	                      }
						  
					  }
					  break;
					  case 2:
					  {
						  System.out.println("enter  account number to withdraw money:");
	        	          int ACW=sc.nextInt();
	        	          for(i=0;i<cnt;i++)
	                      {

		                   if(ACW==arr[i].getAcc_No()) 
		                   {
		                	 
			                 arr[i].withdraw();
			                 
	                       }
		                   else
		                   {
		                	   System.out.println("account dosent exists");
		                   }
		                   }
						  
					  }
					  break;
					  case 3:
					  {
						  System.out.println("enter  account number to calculate your account:");
	        	          int ACW=sc.nextInt();
	        	          for(i=0;i<cnt;i++)
	                      {

		                   if(ACW==arr[i].getAcc_No()) 
		                   {
			                 arr[i].intrest();
	                       }
		                   else
		                   {
		                	   System.out.println("account dosent exists");
		                   }  
		                   }
						  
						  
					  }
					  break;
					  case 4:
					  {
						  int index = 0;
						  
						  System.out.println("enter  account number to delete your account:");
	        	          int ACW=sc.nextInt();
	        	          for(i=0;i<cnt;i++)
	                      {
	        	        	  

		                   if(ACW==arr[i].getAcc_No()) 
		                   {
			                 i=index;
			                 break;
	                       }
		                   else {
		                	   System.out.println("account dosent exists");
		                        }
	                      }
	        	          if(index!=-1)
	        	          {  
	        	              for(i=index;i<cnt-1;i++)
	        	              {
	        	        	  arr[i]=arr[i+1];
	        	              }
	        	          }
	        	          System.out.println("your account sucessfully deleted");
					  }
					  break;
					  }
				  }while(us!=5);
				}
				break;
			    }
		      }while(n!=3);
		
		
		
	}

}
