package com.example.Tank_Game_Pro_2.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Tank_Game_Pro_2.service.service;

@RestController
@CrossOrigin("*")

@RequestMapping("/select")
public class Controller {
	@Autowired
	service serv;

	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	public service getServ() {
		return serv;
	}

	public void setServ(service serv) {
		this.serv = serv;
	}

	public Controller(service serv) {
		super();
		this.serv = serv;
	}

	@GetMapping("/first")
	public  ResponseEntity<Object> method1(@RequestParam(name="tankid") int tankid) {
		System.out.println(tankid+"..................................hello world..................................................................");
		 return serv.mehthod1(tankid);
	}

	@GetMapping("/second")
	public ResponseEntity<Object> method2(@RequestParam(name="tankid") int tankid) {
		return serv.mehthod2(tankid);
	}

	@GetMapping("/victory")
	public ResponseEntity<String> method() {
		return serv.victorious();
	}
}
