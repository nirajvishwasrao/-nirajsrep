import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SecondTankComponent } from './component/second-tank/second-tank.component';
import { FirstTankComponent } from './component/first-tank/first-tank.component';
import { ResultComponent } from './component/result/result.component';
const routes: Routes = [
  
  { path : "first",component:FirstTankComponent},
   { path : "second",component:SecondTankComponent},
   {path : "result", component:ResultComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
