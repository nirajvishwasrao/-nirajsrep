package company;
import java.util.*;
abstract class employee {
	
	int id;
	int sal;
	String name;
	
	
public employee() {
		super();
		// TODO Auto-generated constructor stub
	}

public employee(int id, int sal, String name) {
	super();
	this.id = id;
	this.sal = sal;
	this.name = name;
}


public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getSal() {
	return sal;
}

public void setSal(int sal) {
	this.sal = sal;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

 abstract void calsal();
 abstract void display();
 abstract void newemp();

}
