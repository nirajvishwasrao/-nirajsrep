package house.automation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MainApp {

	ArrayList<Room> roomarr = new ArrayList<>();
	
	
	public static void main(String[] args) {
		MainApp app = new MainApp();
		Scanner sc1 = new Scanner (System.in);
		
		
		int choice=0;
			do
			{
				
				try
				{
					Scanner sc = new Scanner (System.in);
					
					System.out.println("1.Add Rooms To Your House");
					System.out.println("2.For Adding Gadgets");
					System.out.println("3.Display");
					System.out.println("4.Switch");
					System.out.println("5.Time Of Current State");
					System.out.println("6.Exit");
					System.out.println("Enter Your Choice:");
					choice = sc.nextInt();
					
					if(choice==1)
					{
						app.createRooms();
					}
					
					
					if(choice==2)
					{
						boolean check=false;
						if (app.roomarr.size()==0)
						{
							System.out.println("No Rooms To Add Gadgets!!!");
							System.out.println("_________________________________________________________________________");
						}
						else
						{
							System.out.println("Enter The Type Of Room In Which You Want To Add Gadgets:");
							String typeChoice=sc.next();
							typeChoice = typeChoice.toUpperCase();
							for(int index=0;index<app.roomarr.size();index++)
							{
								if(app.roomarr.get(index).getType().equals(typeChoice))
								{
									check = true;
									app.roomarr.get(index).installGadgets();
								}
							}
							if(!check)
							{
								System.out.println("Room Not Found!!!");
								System.out.println("_________________________________________________________________________");
							}
						}
							
					}
					
					if(choice==3)
					{
						app.display();
					}
					if(choice==4)
					{
						boolean check=false;
						if (app.roomarr.size()==0)
						{
							System.out.println("No Rooms Now!!!");
							System.out.println("_________________________________________________________________________");
						}
						else
						{
							System.out.println("Enter The Name Of That Room Whose Gadget's Status You Want To SWitch:");
							String typeChoice=sc.next();
							typeChoice = typeChoice.toUpperCase();
							
							for(int index=0;index<app.roomarr.size();index++)
							{
								if(app.roomarr.get(index).getType().equals(typeChoice))
								{
									app.roomarr.get(index).switchGadgetSatus();
									check = true;
								}
							}
							if(!check)
							{
								System.out.println("Room Not Found!!!");
								System.out.println("_________________________________________________________________________");
							}
						}
						
					}
					if(choice==5)
					{
						boolean check = false;
						if (app.roomarr.size()==0)
						{
							System.out.println("No Rooms Now!!!");
							System.out.println("_________________________________________________________________________");
						}
						else
						{
							System.out.println("Enter The Name Of That Room Whose Gadget's Satus Time You Want To Check:");
							String typeChoice=sc.next();
							typeChoice = typeChoice.toUpperCase();
							for(int index=0;index<app.roomarr.size();index++)
							{
								if(app.roomarr.get(index).getType().equals(typeChoice))
								{
									app.roomarr.get(index).checkTime();
									check = true;
								}
							}
							if(!check)
							{
								System.out.println("Room Not Found!!!");
								System.out.println("_________________________________________________________________________");
							}
						}
					}
					
					if(choice==6)
					{
						System.out.println("End Of Program");
						System.out.println("_________________________________________________________________________");
					}
					if(choice<1 || choice>5)
					{
						//System.out.println("Invalid Choice!!!");
						throw new InvalidChoice();
						
					}
				}
				catch(InputMismatchException e)
				{
					System.out.println("Invalid Choice Please Enter A Valid Number!!!");
					System.out.println("_________________________________________________________________________");
				}
				catch(InvalidChoice f)
				{
					System.out.println("Invlid Choice!!!");
					System.out.println("Choice Must Be 1 to 6");
					System.out.println("Please Enter A Valid Choice!!!!");
					System.out.println("_________________________________________________________________________");
				}
				//sc1.nextLine();
				
				
			}while(choice!=6);
		
		
		
		
		
		
		

	}//main ends here
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void createRooms() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Type Of Room You Want to Add");
		String roomType=sc.nextLine();
		roomType=roomType.toUpperCase();
		roomarr.add(new Room(roomType));
		System.out.println("Room Created Successfully");
		System.out.println("_________________________________________________________________________");
		return;
		
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void display()
	{
		if(roomarr.size()==0)
		{
			System.out.println("No Rooms To Display");
		}
		for(int index=0;index<roomarr.size();index++)
		{
			System.out.println("Room Type: "+roomarr.get(index).getType()+"\nHas Devices:");
			
			for(int index2=0;index2<(roomarr.get(index).gadgetArr.size());index2++)
			{
				System.out.println((index2+1)+"."+roomarr.get(index).gadgetArr.get(index2).getName().toUpperCase()+"\t\t");
			}
			System.out.println("_________________________________________________________________________");
		}
	}
}
