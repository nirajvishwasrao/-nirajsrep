package Accounts;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public  class SavingAccount extends Account{
	  double Min_Balance;
	  
	  public SavingAccount() {
		
	}
	  public SavingAccount(int A_n,double Bal,String Nm,float I_r,double M_b,int Tp,double pa) {
	    	 super(A_n,Bal,Nm,I_r,Tp,pa);
	    	 Min_Balance=M_b;
	    	 
	    	 
	     }
	public double getMin_Balance() {
		return Min_Balance;
	}
	public void setMin_Balance(double min_Balance) {
		Min_Balance = min_Balance;
	}
	
	
	public int  Acc_Number() {
	        Acc_No= ThreadLocalRandom.current().nextInt(100,200);
        return Acc_No;
	}
	
	public void add() {
    	Scanner sc=new Scanner(System.in);
    	
    	
    	System.out.println("Enter your name:");
    	Name=sc.nextLine();
    	System.out.println("Your Account number is:");
    	System.out.print(Acc_No);
    	System.out.println("\nEnter Initial Balance in your account ₹:");
    	Balance=sc.nextDouble();
    	
	}
	
	void display() {
		System.out.println("your account number is: ");
		System.out.print(Acc_No);
		System.out.println("\nyour name is :" +Name);
		System.out.printf("\nAmount is:",+Balance);
		
	}
    public void deposite() {
     
     Scanner sc=new Scanner(System.in);
     System.out.println("you need to have atleast 10,000 in you saving account");
     System.out.println("enter amount to add in your account");
     Min_Balance=sc.nextDouble();
     Balance=Balance+Min_Balance;
     System.out.println("your account balance is:₹"+Balance);
     
    }
	
	void withdraw() {
		Scanner sc=new Scanner(System.in);
	     System.out.println("enter amount to withdraw from your account ₹");
	     Min_Balance=sc.nextDouble();
	     if(Min_Balance<=(Balance-10000))
	     {
	          if(Min_Balance<=25000) {
	          Balance=Balance-Min_Balance;
	          System.out.println("your account balance is:₹"+Balance);
	          }
	          else
	          {
	        	  System.out.println("you can not withdraw more than ₹25000 in a one day");
	          }
	     }
	     else
	     {
	    	 System.out.println("you can not withdraw more than ₹"+(Balance-10000)+" from your bank account");
	    	 System.out.println("You need to keep atleast ₹10000 in your account");
	     }
	     
	}
	void intrest() {
		Intrest_Rate= (float) 6.0;
	     System.out.printf(" Annual intrest for saving account is:");
	     System.out.println(Intrest_Rate);
	     Scanner sc=new Scanner(System.in);
	     
	     System.out.println("enter how much months time period using for calculate intrest:");
	     Time_Period_for_intrest=sc.nextInt();
	     
	     System.out.println("Enter principle amount for calculate simple intrest ₹");
	     P_amount = sc.nextDouble();
	     double Si= ((P_amount * Time_Period_for_intrest * Intrest_Rate)/100);
		 System.out.println("Your Simple intrest amount for saving account is:₹" +Si);
	}
    
}
