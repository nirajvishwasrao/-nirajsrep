import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrl: './update-customer.component.css'
})
export class UpdateCustomerComponent {
  fg!: FormGroup;
  constructor(private customerservice: CustomerService,private router:Router, private fb:FormBuilder){

  }

  ngOnInit(){
    this.fg=this.fb.group({
      empid:[null,Validators.required]
    })
  }

  deleteemp(){
    this.customerservice.deleteallcustomer(this.fg.value).subscribe((res)=>{console.log(res)})
  }
}
