package company;

import java.util.Scanner;

public class tester extends developer {
	int errorsoccured;

	

	public tester(int id, int sal, String name, int npd, int errorsoccured) {
		super(id, sal, name, npd);
		this.errorsoccured = errorsoccured;
	}



	public tester() {
		// TODO Auto-generated constructor stub
	}



	public int getErrorsoccured() {
		return errorsoccured;
	}



	public void setErrorsoccured(int errorsoccured) {
		this.errorsoccured = errorsoccured;
	}



	@Override
	public void calsal() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		super.calsal();
		System.out.println("enrer the errorsoccured of employee");
		errorsoccured = sc.nextInt();
	}



	@Override
	public void display() {
		// TODO Auto-generated method stub
		super.display();
		System.out.println("number of error caught "+errorsoccured);
		
	}



	@Override
	public void newemp() {
		// TODO Auto-generated method stub
		
	}
	

}
