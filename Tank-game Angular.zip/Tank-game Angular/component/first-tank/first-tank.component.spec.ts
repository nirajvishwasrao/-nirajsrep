import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstTankComponent } from './first-tank.component';

describe('FirstTankComponent', () => {
  let component: FirstTankComponent;
  let fixture: ComponentFixture<FirstTankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FirstTankComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FirstTankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
